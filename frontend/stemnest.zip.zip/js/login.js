/* ═══════════════════════════════════════════════════════
   STEMNEST ACADEMY — LOGIN.JS
   Role switcher, form validation, login handler.
═══════════════════════════════════════════════════════ */

let currentRole = 'tutor';

const loginConfig = {
  tutor: {
    eyebrowClass: 'eyebrow-tutor',
    eyebrowText:  '📡 Tutor Portal',
    title:        'Welcome back,<br>ready to teach? 👋',
    sub:          'Log in to access your dashboard, schedule and upcoming live sessions.',
    btnClass:     'btn-tutor-login',
    btnIcon:      '🎓',
    btnText:      'Log In as Tutor',
    tutorActive:  'active-tutor',
    studentActive:'',
    panelClass:   'panel-tutor',
    panelIcon:    '🎓',
    panelTitle:   'Your students<br>are waiting!',
    panelSub:     "Head into your dashboard, review today's schedule and start your next live 1-on-1 session.",
    ctaText:      '👩‍🏫 Join Us as a Tutor',
    ctaAction:    () => navigate('home'),
    cards: `
      <div class="pcard">
        <div class="pcard-icon">📅</div>
        <div><div class="pcard-title">Next session in 20 mins</div><div class="pcard-sub">James O. · Year 9 Maths</div></div>
      </div>
      <div class="pcard">
        <div class="pcard-icon">📊</div>
        <div><div class="pcard-title">4 sessions scheduled today</div><div class="pcard-sub">Coding · Maths · Sciences</div></div>
      </div>
      <div class="pcard">
        <div class="pcard-icon">⭐</div>
        <div><div class="pcard-title">Your rating: 4.9 / 5</div><div class="pcard-sub">Based on 48 student reviews</div></div>
      </div>`,
  },
  student: {
    eyebrowClass: 'eyebrow-student',
    eyebrowText:  '🧑‍💻 Student Portal',
    title:        "Hey there,<br>ready to learn? 🚀",
    sub:          "Log in to join your live class, check homework and see how far you've come.",
    btnClass:     'btn-student-login',
    btnIcon:      '🚀',
    btnText:      'Log In & Join Class',
    tutorActive:  '',
    studentActive:'active-student',
    panelClass:   'panel-student',
    panelIcon:    '🧑‍💻',
    panelTitle:   'Your class is<br>live & waiting!',
    panelSub:     "Jump in, your tutor is online and ready to help you learn something amazing today.",
    ctaText:      '🎓 Book a Free Trial Class — No commitment needed',
    ctaAction:    () => navigate('home'),
    cards: `
      <div class="pcard">
        <div class="pcard-icon">📡</div>
        <div><div class="pcard-title"><span class="live-dot"></span>Live Now — Python Class</div><div class="pcard-sub">Tutor: Sarah R. · 10:00 AM</div></div>
      </div>
      <div class="pcard">
        <div class="pcard-icon">🏆</div>
        <div><div class="pcard-title">You've completed 12 classes</div><div class="pcard-sub">Keep going — you're on a roll!</div></div>
      </div>
      <div class="pcard">
        <div class="pcard-icon">📝</div>
        <div><div class="pcard-title">1 homework task due</div><div class="pcard-sub">Python: Variables & Loops</div></div>
      </div>`,
  },
};

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', () => {
  seedRegistries();   // ensure defaults exist before any login attempt
  switchRole('tutor');
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter') handleLogin();
  });
});

/* ── SEED DEFAULT REGISTRIES (runs once, skips if already populated) ── */
function seedRegistries() {
  // Teachers
  if (!localStorage.getItem('sn_teachers') || JSON.parse(localStorage.getItem('sn_teachers')).length === 0) {
    const teachers = [
      { id:'CT001', name:'Sarah Rahman',  initials:'SR', subject:'Coding',   email:'sarah.rahman@stemnest.co.uk',  password:'StemNest2024!', courses:['Python for Beginners','Scratch & Game Design','Web Dev: HTML/CSS/JS'], gradeGroups:['Year 7–9','Year 10–11'], availability:'Mon–Fri, 9am–6pm', dbs:'yes', color:'linear-gradient(135deg,#1a56db,#4f87f5)', photo:null },
      { id:'MT001', name:'James Okafor',  initials:'JO', subject:'Maths',    email:'james.okafor@stemnest.co.uk',  password:'StemNest2024!', courses:['Primary Maths Boost','GCSE Maths Prep','A-Level Maths Mastery'],         gradeGroups:['Year 7–9','Year 10–11','Year 12–13'], availability:'Mon–Sat, 10am–7pm', dbs:'yes', color:'linear-gradient(135deg,#0e9f6e,#3dd9a4)', photo:null },
      { id:'ST001', name:'Lisa Patel',    initials:'LP', subject:'Sciences', email:'lisa.patel@stemnest.co.uk',    password:'StemNest2024!', courses:['GCSE Biology','GCSE Chemistry','A-Level Physics'],                         gradeGroups:['Year 10–11','Year 12–13'], availability:'Tue–Sat, 11am–6pm', dbs:'yes', color:'linear-gradient(135deg,#ff6b35,#ffaa80)', photo:null },
      { id:'CT002', name:'Marcus King',   initials:'MK', subject:'Coding',   email:'marcus.king@stemnest.co.uk',   password:'StemNest2024!', courses:['Python for Beginners','AI Literacy','A-Level Computer Science'],           gradeGroups:['Year 10–11','Year 12–13'], availability:'Mon–Fri, 2pm–9pm', dbs:'yes', color:'linear-gradient(135deg,#7c3aed,#a78bfa)', photo:null },
    ];
    localStorage.setItem('sn_teachers', JSON.stringify(teachers));
  }

  // Sales persons
  if (!localStorage.getItem('sn_sales_persons') || JSON.parse(localStorage.getItem('sn_sales_persons')).length === 0) {
    const salesPersons = [
      { id:'SP001', name:'Alex Johnson', initials:'AJ', email:'alex.johnson@stemnest.co.uk', password:'StemNest2024!', region:'UK & Europe',   bio:'Senior academic counselor.', color:'linear-gradient(135deg,#ff6b35,#fbbf24)', photo:null },
    ];
    localStorage.setItem('sn_sales_persons', JSON.stringify(salesPersons));
  }

  // Operations, Pre-Sales, Post-Sales, HR staff
  if (!localStorage.getItem('sn_staff') || JSON.parse(localStorage.getItem('sn_staff')).length === 0) {
    const staff = [
      { id:'OPS001', name:'Operations Team', email:'ops@stemnest.co.uk',      password:'StemNest2024!', role:'operations' },
      { id:'PS001',  name:'Pre-Sales Team',  email:'presales@stemnest.co.uk', password:'StemNest2024!', role:'presales'   },
      { id:'POS001', name:'Post-Sales Team', email:'postsales@stemnest.co.uk',password:'StemNest2024!', role:'postsales'  },
      { id:'HR001',  name:'HR Team',         email:'hr@stemnest.co.uk',       password:'StemNest2024!', role:'hr'         },
    ];
    localStorage.setItem('sn_staff', JSON.stringify(staff));
  }
}

/* ── SWITCH ROLE ── */
function switchRole(role) {
  currentRole = role;
  const c = loginConfig[role];

  // Toggle buttons
  document.getElementById('tutorBtn').className   = 'role-btn ' + c.tutorActive;
  document.getElementById('studentBtn').className = 'role-btn ' + c.studentActive;

  // Welcome copy
  const ey = document.getElementById('formEyebrow');
  ey.className   = 'form-eyebrow ' + c.eyebrowClass;
  ey.textContent = c.eyebrowText;
  document.getElementById('formTitle').innerHTML = c.title;
  document.getElementById('formSub').textContent = c.sub;

  // Input focus colour
  const pw = document.getElementById('passwordInput');
  const em = document.getElementById('emailInput');
  if (role === 'student') {
    pw?.classList.add('focus-green');
    em?.classList.add('focus-green');
  } else {
    pw?.classList.remove('focus-green');
    em?.classList.remove('focus-green');
  }

  // Login button
  const btn = document.getElementById('loginBtn');
  btn.className = 'login-btn ' + c.btnClass;
  document.getElementById('btnIcon').textContent = c.btnIcon;
  document.getElementById('btnText').textContent = c.btnText;

  // Right panel
  document.getElementById('brandPanel').className = 'brand-panel ' + c.panelClass;
  document.getElementById('panelIcon').textContent  = c.panelIcon;
  document.getElementById('panelTitle').innerHTML   = c.panelTitle;
  document.getElementById('panelSub').textContent   = c.panelSub;
  document.getElementById('panelCards').innerHTML   = c.cards;

  // CTA link below divider
  const cta = document.getElementById('loginCtaLink');
  cta.innerHTML = c.ctaText;
  cta.onclick   = c.ctaAction;
}

/* ── PASSWORD TOGGLE ── */
function togglePw() {
  const inp = document.getElementById('passwordInput');
  const btn = document.getElementById('pwToggle');
  if (inp.type === 'password') { inp.type = 'text';     btn.textContent = '🙈'; }
  else                         { inp.type = 'password'; btn.textContent = '👁️'; }
}

/* ── HANDLE LOGIN ── */
function handleLogin() {
  const email = document.getElementById('emailInput')?.value.trim();
  const pw    = document.getElementById('passwordInput')?.value;
  const btn   = document.getElementById('loginBtn');

  if (!email || !pw) {
    btn.style.animation = 'none';
    btn.offsetHeight;
    btn.style.animation = 'shake .4s ease';
    return;
  }

  btn.style.opacity       = '0.7';
  btn.style.pointerEvents = 'none';
  document.getElementById('btnText').textContent = 'Logging in…';
  document.getElementById('btnIcon').textContent = '⏳';

  setTimeout(() => {
    btn.style.opacity       = '1';
    btn.style.pointerEvents = '';

    if (currentRole === 'tutor') {
      // Check teacher registry
      const teachers = JSON.parse(localStorage.getItem('sn_teachers') || '[]');
      const teacher  = teachers.find(t =>
        t.email.toLowerCase() === email.toLowerCase() && t.password === pw
      );

      // Check sales persons registry
      const salesPersons = JSON.parse(localStorage.getItem('sn_sales_persons') || '[]');
      const salesPerson  = salesPersons.find(s =>
        s.email.toLowerCase() === email.toLowerCase() && s.password === pw
      );

      // Check staff registry (ops, presales, postsales, hr)
      const staff = JSON.parse(localStorage.getItem('sn_staff') || '[]');
      const staffMember = staff.find(s =>
        s.email.toLowerCase() === email.toLowerCase() && s.password === pw
      );

      if (teacher) {
        localStorage.setItem('sn_logged_in_teacher', teacher.id);
        document.getElementById('btnIcon').textContent = '✅';
        document.getElementById('btnText').textContent = `Welcome back, ${teacher.name.split(' ')[0]}! Redirecting…`;
        setTimeout(() => navigate('tutor-dashboard'), 700);
      } else if (salesPerson) {
        localStorage.setItem('sn_logged_in_sales', salesPerson.id);
        document.getElementById('btnIcon').textContent = '✅';
        document.getElementById('btnText').textContent = `Welcome, ${salesPerson.name.split(' ')[0]}! Redirecting…`;
        setTimeout(() => navigate('sales-dashboard'), 700);
      } else if (staffMember) {
        document.getElementById('btnIcon').textContent = '✅';
        document.getElementById('btnText').textContent = `Welcome! Redirecting…`;
        setTimeout(() => navigate(staffMember.role), 700);
      } else if (email === 'admin@stemnest.co.uk' && pw === 'admin123') {
        document.getElementById('btnIcon').textContent = '✅';
        document.getElementById('btnText').textContent = 'Welcome, Admin! Redirecting…';
        setTimeout(() => navigate('admin-dashboard'), 700);
      } else if (email === 'founder@stemnest.co.uk' && pw === 'Founder2024!') {
        document.getElementById('btnIcon').textContent = '✅';
        document.getElementById('btnText').textContent = 'Welcome, Founder! Redirecting…';
        setTimeout(() => navigate('super-admin'), 700);
      } else {
        document.getElementById('btnIcon').textContent = '❌';
        document.getElementById('btnText').textContent = 'Invalid credentials';
        btn.style.animation = 'none';
        btn.offsetHeight;
        btn.style.animation = 'shake .4s ease';
        setTimeout(() => {
          document.getElementById('btnIcon').textContent = loginConfig[currentRole].btnIcon;
          document.getElementById('btnText').textContent = loginConfig[currentRole].btnText;
        }, 1500);
      }
    } else {
      // Student login
      document.getElementById('btnIcon').textContent = '✅';
      document.getElementById('btnText').textContent = 'Joining your class…';
      setTimeout(() => navigate('student-dashboard'), 700);
    }
  }, 1200);
}
